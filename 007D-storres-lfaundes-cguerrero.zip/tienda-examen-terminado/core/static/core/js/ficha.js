$(document).ready(function() {

  // **************************************************************
  // Los botones de pago serán desarrollados en una versión futura
  // **************************************************************

  // $('#comprar-ahora').click(function() {
  //   $('#accion').val('comprar-ahora');
  //   $('#formulario-ficha').submit();
  // });

  // $('#agregar-al-carrito').click(function() {
  //   $('#accion').val('agregar-al-carrito');
  //   $('#formulario-ficha').submit();
  // });

});