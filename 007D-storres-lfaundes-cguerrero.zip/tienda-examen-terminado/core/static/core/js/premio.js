$(document).ready(function() {

  $.get('https://fakestoreapi.com/products', function(registros){

      $.each(registros, function(i, item) {  // Recorrer los registros devueltos por la API
        
        var recuadro = `
                    <div class="card ropa_carta">
                        <img src="${item.image}" class="card-img-top ropa_carta_imagen">
                        <ul class="list-group list-group-flush">
                        <li class="list-group-item ropa_carta_titulo">${item.title}</li>
                        <li class="list-group-item">${item.price}</li>
                        <li class="list-group-item">$${item.description}</li>
                        </ul>
                    </div>
                    
                    `;
                    
        // Agregar el recuadro a la lista de premios
        $('#lista').append(recuadro);
      
    });

    setTimeout(`
      $('#imagen-de-espera').hide();
      $('#capa-cubre-todo').hide();
      `, 2000);

  });

});