Integrantes

Nombre: Sebastian Andres Torres Saez
Seccion: 007D
Correo: seba.torress@duocuc.cl

Nombre: Luis Felipe Faundes Villalobos
Seccion: 007D
Correo: lu.faundes@duocuc.cl

Nombre: Christopher Andree Guerrero de la Pena
Seccion: 007D
Correo: ch.guerrerod@duocuc.cl

Github: https://github.com/sebatores/tienda-web-examen