import sqlite3
from django.contrib.auth.models import User, Permission
from django.db import connection
from datetime import date, timedelta
from random import randint
from core.models import Categoria, Producto, Carrito, Perfil, Boleta, DetalleBoleta, Bodega

def eliminar_tabla(nombre_tabla):
    conexion = sqlite3.connect('db.sqlite3')
    cursor = conexion.cursor()
    cursor.execute(f"DELETE FROM {nombre_tabla}")
    conexion.commit()
    conexion.close()

def exec_sql(query):
    with connection.cursor() as cursor:
        cursor.execute(query)

def crear_usuario(username, tipo, nombre, apellido, correo, es_superusuario, 
    es_staff, rut, direccion, subscrito, imagen):

    try:
        print(f'Verificar si existe usuario {username}.')

        if User.objects.filter(username=username).exists():
            print(f'   Eliminar {username}')
            User.objects.get(username=username).delete()
            print(f'   Eliminado {username}')
        
        print(f'Iniciando creación de usuario {username}.')

        usuario = None
        if tipo == 'Superusuario':
            print('    Crear Superuser')
            usuario = User.objects.create_superuser(username=username, password='123')
        else:
            print('    Crear User')
            usuario = User.objects.create_user(username=username, password='123')

        if tipo == 'Administrador':
            print('    Es administrador')
            usuario.is_staff = es_staff
            
        usuario.first_name = nombre
        usuario.last_name = apellido
        usuario.email = correo
        usuario.save()

        if tipo == 'Administrador':
            print(f'    Dar permisos a core y apirest')
            permisos = Permission.objects.filter(content_type__app_label__in=['core', 'apirest'])
            usuario.user_permissions.set(permisos)
            usuario.save()
 
        print(f'    Crear perfil: RUT {rut}, Subscrito {subscrito}, Imagen {imagen}')
        Perfil.objects.create(
            usuario=usuario, 
            tipo_usuario=tipo,
            rut=rut,
            direccion=direccion,
            subscrito=subscrito,
            imagen=imagen)
        print("    Creado correctamente")
    except Exception as err:
        print(f"    Error: {err}")

def eliminar_tablas():
    eliminar_tabla('auth_user_groups')
    eliminar_tabla('auth_user_user_permissions')
    eliminar_tabla('auth_group_permissions')
    eliminar_tabla('auth_group')
    eliminar_tabla('auth_permission')
    eliminar_tabla('django_admin_log')
    eliminar_tabla('django_content_type')
    #eliminar_tabla('django_migrations')
    eliminar_tabla('django_session')
    eliminar_tabla('Bodega')
    eliminar_tabla('DetalleBoleta')
    eliminar_tabla('Boleta')
    eliminar_tabla('Perfil')
    eliminar_tabla('Carrito')
    eliminar_tabla('Producto')
    eliminar_tabla('Categoria')
    #eliminar_tabla('authtoken_token')
    eliminar_tabla('auth_user')

def poblar_bd(test_user_email=''):
    eliminar_tablas()

    crear_usuario(
        username='fjimenez',
        tipo='Cliente', 
        nombre='Felipe', 
        apellido='Jimenez', 
        correo=test_user_email if test_user_email else 'fjimenez@gmail.com', 
        es_superusuario=False, 
        es_staff=False, 
        rut='19.550.066-5',	
        direccion='Av. Providencia 1234, Providencia, \nSantiago 7500000 \nChile', 
        subscrito=True, 
        imagen='perfiles/fjimenez.jpg')

    crear_usuario(
        username='mrodriguez',
        tipo='Cliente', 
        nombre='Maria', 
        apellido='Rodriguez', 
        correo=test_user_email if test_user_email else 'mrodriguez@gmail.com', 
        es_superusuario=False, 
        es_staff=False, 
        rut='20.834.924-4', 
        direccion='Calle San Francisco 987, Recoleta \nSantiago 8420000 \nChile', 
        subscrito=True, 
        imagen='perfiles/mrodriguez.jpg')

    crear_usuario(
        username='jgonzalez',
        tipo='Cliente', 
        nombre='Juan', 
        apellido='Gonzalez', 
        correo=test_user_email if test_user_email else 'jgonzalez@gmail.com', 
        es_superusuario=False, 
        es_staff=False, 
        rut='22.160.912-3', 
        direccion='Calle Bellavista 123, Bellavista, \nSantiago 8420508 \nChile', 
        subscrito=False, 
        imagen='perfiles/jgonzalez.jpg')

    crear_usuario(
        username='clopez',
        tipo='Cliente', 
        nombre='Carla', 
        apellido='Lopez', 
        correo=test_user_email if test_user_email else 'clopez@gmail.com', 
        es_superusuario=False, 
        es_staff=False, 
        rut='13.385.570-K', 
        direccion='Av. Las Condes 7890, Las Condes, \nSantiago 7550000 \nChile', 
        subscrito=False, 
        imagen='perfiles/clopez.jpg')

    crear_usuario(
        username='lfernandez',
        tipo='Administrador', 
        nombre='Luis', 
        apellido='Fernandez', 
        correo=test_user_email if test_user_email else 'lfernandez@gmail.com', 
        es_superusuario=False, 
        es_staff=True, 
        rut='22.709.161-4', 
        direccion='Calle Los Leones 789, Providencia, \nSantiago 7510000 \nChile', 
        subscrito=False, 
        imagen='perfiles/lfernandez.jpg')
    
    crear_usuario(
        username='msilva',
        tipo='Administrador', 
        nombre='Martin', 
        apellido='Silva', 
        correo=test_user_email if test_user_email else 'msilva@gmail.com', 
        es_superusuario=False, 
        es_staff=True, 
        rut='18.486.512-2', 
        direccion='Calle Carmen 567, Santiago Centro, \nSantiago \nChile', 
        subscrito=False, 
        imagen='perfiles/msilva.jpg')

    crear_usuario(
        username='super',
        tipo='Superusuario',
        nombre='Elena',
        apellido='Alvarez',
        correo=test_user_email if test_user_email else 'ealvarez@gmail.com',
        es_superusuario=True,
        es_staff=True,
        rut='20.235.197-2',
        direccion='AV. Matta 234, Santiago Centro, \nSantiago 8332000 \nChile',
        subscrito=False,
        imagen='perfiles/ealvarez.jpg')
    
    categorias_data = [
        { 'id': 1, 'nombre': 'Acción'},
        { 'id': 2, 'nombre': 'Aventura'},
        { 'id': 3, 'nombre': 'Estrategia'},
        { 'id': 4, 'nombre': 'RPG'},
    ]

    print('Crear categorías')
    for categoria in categorias_data:
        Categoria.objects.create(**categoria)
    print('Categorías creadas correctamente')

    productos_data = [
        # Categoría "Acción" (8 juegos)
        {
            'id': 1,
            'categoria': Categoria.objects.get(id=1),
            'nombre': 'God of War 2',
            'descripcion': 'Kratos, un guerrero espartano, busca venganza contra el dios de la guerra, Ares. El juego combina combates intensos con elementos de la mitología griega.',
            'precio': 15990,
            'descuento_subscriptor': 10,
            'descuento_oferta': 20,
            'imagen': 'productos/GodofWar2.jpg'
        },
        {
            'id': 2,
            'categoria': Categoria.objects.get(id=1),
            'nombre': 'Devil May Cry 2',
            'descripcion': 'Dante, un cazador de demonios con habilidades sobrehumanas, en su misión de derrotar a Mundus, el emperador demonio. Con un estilo de combate rápido y estilizado, el juego se ha convertido en un clásico del género.',
            'precio': 11990,
            'descuento_subscriptor': 10,
            'descuento_oferta': 15,
            'imagen': 'productos/DevilMayCry2.jpg'
        },
        {
            'id': 3,
            'categoria': Categoria.objects.get(id=1),
            'nombre': 'Grand Theft Auto: San Andreas',
            'descripcion': 'Juego de acción y aventura de mundo abierto. El jugador sigue la historia de Carl "CJ" Johnson, quien regresa a Los Santos para reconstruir su vida y su pandilla, enfrentándose a mafias, policías corruptos y otros desafíos en un vasto entorno urbano.',
            'precio': 14990,
            'descuento_subscriptor': 10,
            'descuento_oferta': 5,
            'imagen': 'productos/GTA.jpg'
        },
        {
            'id': 4,
            'categoria': Categoria.objects.get(id=1),
            'nombre': 'The Warriors',
            'descripcion': 'El jugador controla a miembros de la pandilla The Warriors mientras luchan por regresar a su territorio en Coney Island después de ser incriminados por un asesinato. El juego se centra en el combate cuerpo a cuerpo y en la vida de pandillas en las calles de Nueva York.',
            'precio': 12990,
            'descuento_subscriptor': 20,
            'descuento_oferta': 0,
            'imagen': 'productos/TheWarriors.jpg'
        },
        {
            'id': 5,
            'categoria': Categoria.objects.get(id=1),
            'nombre': 'Max Payne 2: The Fall of Max Payne',
            'descripcion': 'Un ex-detective de la policía de Nueva York, mientras investiga una serie de asesinatos en medio de una conspiración. Con su característica jugabilidad de "tiempo bala", el juego ofrece combates intensos y una narrativa oscura y emotiva.',
            'precio': 16990,
            'descuento_subscriptor': 5,
            'descuento_oferta': 30,
            'imagen': 'productos/MaxPayne2.jpg'
        },
        {
            'id': 6,
            'categoria': Categoria.objects.get(id=1),
            'nombre': 'Black',
            'descripcion': 'Los jugadores toman el control de un operativo de las fuerzas especiales en misiones llenas de adrenalina y explosiones, enfrentándose a numerosos enemigos con una amplia variedad de armas.',
            'precio': 9990,
            'descuento_subscriptor': 0,
            'descuento_oferta': 10,
            'imagen': 'productos/Black.jpg'
        },
        {
            'id': 7,
            'categoria': Categoria.objects.get(id=1),
            'nombre': 'Resident Evil 4',
            'descripcion': 'Leon S. Kennedy, un agente especial encargado de rescatar a la hija del presidente de los Estados Unidos. El juego combina elementos de disparos y supervivencia mientras Leon se enfrenta a hordas de infectados y otros enemigos en un misterioso pueblo europeo.',
            'precio': 19990,
            'descuento_subscriptor': 5,
            'descuento_oferta': 15,
            'imagen': 'productos/ResidentEvil4.jpg'
        },
        {
            'id': 8,
            'categoria': Categoria.objects.get(id=1),
            'nombre': 'Metal Gear Solid 3: Subsistence',
            'descripcion': 'Una versión mejorada de "Metal Gear Solid 3: Snake Eater", que ofrece un enfoque en el sigilo y la supervivencia en un entorno de jungla durante la Guerra Fría. Incluye mejoras en la jugabilidad, una perspectiva de cámara en tercera persona mejorada y contenido adicional.',
            'precio': 16990,
            'descuento_subscriptor': 10,
            'descuento_oferta': 10,
            'imagen': 'productos/MetalGearSolid3.jpg'
        },
        # Categoría "Aventura" (4 juegos)
        {
            'id': 9,
            'categoria': Categoria.objects.get(id=2),
            'nombre': 'The Lord of the Rings: Aragorn\'s Quest',
            'descripcion': 'Juego de acción y aventura en tercera persona que permite a los jugadores experimentar las hazañas heroicas de Aragorn, desde su tiempo como montaraz hasta su coronación como Rey de Gondor. El juego incluye combates dinámicos, exploración y misiones basadas en los eventos de la trilogía cinematográfica de "El Señor de los Anillos".',
            'precio': 15990,
            'descuento_subscriptor': 5,
            'descuento_oferta': 5,
            'imagen': 'productos/TheLordOfTheRings.jpg'
        },
        {
            'id': 10,
            'categoria': Categoria.objects.get(id=2),
            'nombre': 'Prince of Persia: The Sands of Time',
            'descripcion': 'Aventura que combina plataformas acrobáticas, combate y resolución de puzzles. El jugador asume el papel del Príncipe, quien debe usar su agilidad y la daga mágica de las arenas del tiempo para corregir un error que desató el caos en su reino.',
            'precio': 11990,
            'descuento_subscriptor': 30,
            'descuento_oferta': 5,
            'imagen': 'productos/PrinceOfPersia.jpg'
        },
        {
            'id': 11,
            'categoria': Categoria.objects.get(id=2),
            'nombre': 'Tomb Raider: Legend',
            'descripcion': 'Protagonizado por Lara Croft. El juego combina exploración de tumbas, resolución de acertijos y combate. Los jugadores siguen a Lara en su búsqueda de artefactos antiguos y descubren secretos ocultos mientras enfrentan diversos desafíos en exóticos escenarios alrededor del mundo.',
            'precio': 19990,
            'descuento_subscriptor': 10,
            'descuento_oferta': 10,
            'imagen': 'productos/TombRaider.jpg'
        },
        {
            'id': 12,
            'categoria': Categoria.objects.get(id=2),
            'nombre': 'Okami',
            'descripcion': 'Aventura que sigue a Amaterasu, la diosa del sol, que toma la forma de un lobo blanco. El juego combina combates, resolución de acertijos y exploración en un mundo inspirado en la mitología japonesa. Los jugadores utilizan una variedad de técnicas basadas en la pintura para restaurar el mundo y combatir a las fuerzas oscuras.',
            'precio': 9900,
            'descuento_subscriptor': 5,
            'descuento_oferta': 0,
            'imagen': 'productos/Okami.jpg'
        },
        # Categoría "Estrategia" (4 juegos)
        {
            'id': 13,
            'categoria': Categoria.objects.get(id=3),
            'nombre': 'Dynasty Warriors 5: Extreme Legends',
            'descripcion': 'El juego presenta combates masivos con grandes hordas de enemigos y permite a los jugadores tomar el control de varios guerreros históricos de la antigua China. Además de los nuevos personajes y escenarios, ofrece un enfoque en la estrategia y el combate en tiempo real.',
            'precio': 11990,
            'descuento_subscriptor': 0,
            'descuento_oferta': 20,
            'imagen': 'productos/DynastyWarriors5.jpg'
        },
        {
            'id': 14,
            'categoria': Categoria.objects.get(id=3),
            'nombre': 'Star Wars: Battlefront II',
            'descripcion': 'En el universo de Star Wars. El juego ofrece combates en grandes batallas tanto en tierra como en el espacio, permitiendo a los jugadores luchar en diferentes facciones del conflicto galáctico, incluyendo la República, la Confederación, el Imperio y la Alianza Rebelde. También incluye una campaña para un solo jugador y un robusto modo multijugador.',
            'precio': 16990,
            'descuento_subscriptor': 25,
            'descuento_oferta': 5,
            'imagen': 'productos/StarWarsBattlefront2.jpg'
        },
        {
            'id': 15,
            'categoria': Categoria.objects.get(id=3),
            'nombre': 'Commandos: Strike Force',
            'descripcion': 'Tomas el control de un equipo de comandos especializados en operaciones encubiertas y misiones de infiltración. El juego ofrece una mezcla de tácticas, estrategia y combate directo mientras los jugadores ejecutan diversas misiones en entornos variados y desafiantes.',
            'precio': 9990,
            'descuento_subscriptor': 0,
            'descuento_oferta': 5,
            'imagen': 'productos/CommandosStrikeForce.jpg'
        },
        {
            'id': 16,
            'categoria': Categoria.objects.get(id=3),
            'nombre': 'Culdcept',
            'descripcion': 'Un juego de mesa y estrategia que combina elementos de juegos de cartas y tablero. Los jugadores compiten en un tablero utilizando cartas para invocar criaturas y lanzar hechizos con el objetivo de dominar el tablero y derrotar a sus oponentes. El juego ofrece una mezcla única de estrategia y tácticas mientras los jugadores construyen y usan mazos para superar a sus rivales.',
            'precio': 10990,
            'descuento_subscriptor': 5,
            'descuento_oferta': 5,
            'imagen': 'productos/Culdcept.jpg'
        },
        # Categoría "RPG" (4 juegos)
        {
            'id': 17,
            'categoria': Categoria.objects.get(id=4),
            'nombre': 'Gladius',
            'descripcion': 'Rol táctico que se desarrolla en un mundo inspirado en la antigüedad romana. Los jugadores dirigen un grupo de gladiadores en combates tácticos por turnos, mejorando sus habilidades y equipos mientras luchan en la arena para ganar fama y fortuna. El juego combina estrategia por turnos con una rica narrativa y un sistema de progresión para los personajes.',
            'precio': 12990,
            'descuento_subscriptor': 10,
            'descuento_oferta': 0,
            'imagen': 'productos/Gladius.jpg'
        },
        {
            'id': 18,
            'categoria': Categoria.objects.get(id=4),
            'nombre': 'Final Fantasy X-2',
            'descripcion': 'Secuela de "Final Fantasy X". La historia sigue a Yuna y sus compañeras mientras exploran un mundo post-apocalíptico en busca de respuestas y aventuras. El juego presenta un sistema de combate basado en turnos, un sistema de trabajo flexible y una narrativa que se desarrolla a través de misiones secundarias y decisiones del jugador.',
            'precio': 18990,
            'descuento_subscriptor': 10,
            'descuento_oferta': 5,
            'imagen': 'productos/FinalFantasyX2.jpg'
        },
        {
            'id': 19,
            'categoria': Categoria.objects.get(id=4),
            'nombre': 'Kingdom Hearts',
            'descripcion': 'Juego de rol y acción que combina personajes y mundos de Disney con los de Final Fantasy. Los jugadores siguen a Sora, un joven con una llave espada, mientras viaja a través de diversos mundos de Disney y Final Fantasy para detener las fuerzas oscuras y buscar a sus amigos.',
            'precio': 17990,
            'descuento_subscriptor': 20,
            'descuento_oferta': 10,
            'imagen': 'productos/KingdomHearts.jpg'
        },
        {
            'id': 20,
            'categoria': Categoria.objects.get(id=4),
            'nombre': 'Dragon Quest VIII: Journey of the Cursed King',
            'descripcion': 'Un grupo de héroes en su búsqueda para romper una maldición lanzada sobre el reino. Con un mundo abierto para explorar, combates por turnos y una historia épica, el juego ofrece una experiencia clásica de RPG con gráficos cel-shading y una narrativa rica.',
            'precio': 15990,
            'descuento_subscriptor': 5,
            'descuento_oferta': 5,
            'imagen': 'productos/DragonQuestVIII.jpg'
        }
    ]

    print('Crear productos')
    for producto in productos_data:
        Producto.objects.create(**producto)
    print('Productos creados correctamente')

    print('Crear carritos')
    for rut in ['22.709.161-4', '13.385.570-K']:
        cliente = Perfil.objects.get(rut=rut)
        for cantidad_productos in range(1, 11):
            producto = Producto.objects.get(pk=randint(1, 10))
            if cliente.subscrito:
                descuento_subscriptor = producto.descuento_subscriptor
            else:
                descuento_subscriptor = 0
            descuento_oferta = producto.descuento_oferta
            descuento_total = descuento_subscriptor + descuento_oferta
            descuentos = int(round(producto.precio * descuento_total / 100))
            precio_a_pagar = producto.precio - descuentos
            Carrito.objects.create(
                cliente=cliente,
                producto=producto,
                precio=producto.precio,
                descuento_subscriptor=descuento_subscriptor,
                descuento_oferta=descuento_oferta,
                descuento_total=descuento_total,
                descuentos=descuentos,
                precio_a_pagar=precio_a_pagar
            )
    print('Carritos creados correctamente')

    print('Crear boletas')
    nro_boleta = 0
    perfiles_cliente = Perfil.objects.filter(tipo_usuario='Cliente')
    for cliente in perfiles_cliente:
        estado_index = -1
        for cant_boletas in range(1, randint(6, 21)):
            nro_boleta += 1
            estado_index += 1
            if estado_index > 3:
                estado_index = 0
            estado = Boleta.ESTADO_CHOICES[estado_index][1]
            fecha_venta = date(2023, randint(1, 5), randint(1, 28))
            fecha_despacho = fecha_venta + timedelta(days=randint(0, 3))
            fecha_entrega = fecha_despacho + timedelta(days=randint(0, 3))
            if estado == 'Anulado':
                fecha_despacho = None
                fecha_entrega = None
            elif estado == 'Vendido':
                fecha_despacho = None
                fecha_entrega = None
            elif estado == 'Despachado':
                fecha_entrega = None
            boleta = Boleta.objects.create(
                nro_boleta=nro_boleta, 
                cliente=cliente,
                monto_sin_iva=0,
                iva=0,
                total_a_pagar=0,
                fecha_venta=fecha_venta,
                fecha_despacho=fecha_despacho,
                fecha_entrega=fecha_entrega,
                estado=estado)
            detalle_boleta = []
            total_a_pagar = 0
            for cant_productos in range(1, randint(4, 6)):
                producto_id = randint(1, 10)
                producto = Producto.objects.get(id=producto_id)
                precio = producto.precio
                descuento_subscriptor = 0
                if cliente.subscrito:
                    descuento_subscriptor = producto.descuento_subscriptor
                descuento_oferta = producto.descuento_oferta
                descuento_total = descuento_subscriptor + descuento_oferta
                descuentos = int(round(precio * descuento_total / 100))
                precio_a_pagar = precio - descuentos
                bodega = Bodega.objects.create(producto=producto)
                DetalleBoleta.objects.create(
                    boleta=boleta,
                    bodega=bodega,
                    precio=precio,
                    descuento_subscriptor=descuento_subscriptor,
                    descuento_oferta=descuento_oferta,
                    descuento_total=descuento_total,
                    descuentos=descuentos,
                    precio_a_pagar=precio_a_pagar)
                total_a_pagar += precio_a_pagar
            monto_sin_iva = int(round(total_a_pagar / 1.19))
            iva = total_a_pagar - monto_sin_iva
            boleta.monto_sin_iva = monto_sin_iva
            boleta.iva = iva
            boleta.total_a_pagar = total_a_pagar
            boleta.fecha_venta = fecha_venta
            boleta.fecha_despacho = fecha_despacho
            boleta.fecha_entrega = fecha_entrega
            boleta.estado = estado
            boleta.save()
            print(f'    Creada boleta Nro={nro_boleta} Cliente={cliente.usuario.first_name} {cliente.usuario.last_name}')
    print('Boletas creadas correctamente')

    print('Agregar productos a bodega')
    for producto_id in range(1, 11):
        producto = Producto.objects.get(id=producto_id)
        cantidad = 0
        for cantidad in range(1, randint(2, 31)):
            Bodega.objects.create(producto=producto)
        print(f'    Agregados {cantidad} "{producto.nombre}" a la bodega')
    print('Productos agregados a bodega')

